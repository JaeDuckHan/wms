-- TC-007 assert
SELECT status='disposed' AS disposed_ok FROM return_orders WHERE id=23007;
SELECT COUNT(*)=1 AS dispose_txn_created FROM stock_transactions WHERE txn_type='return_dispose' AND ref_id=23107 AND deleted_at IS NULL;
