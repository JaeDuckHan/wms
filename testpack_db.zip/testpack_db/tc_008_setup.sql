-- TC-008 setup
INSERT INTO exchange_rates (id,base_currency,quote_currency,rate,rate_date,status,entered_by,created_at,updated_at) VALUES (8008,'THB','KRW',38.600000,'2026-02-14','draft',1003,NOW(),NOW());
INSERT INTO files (id,file_key,file_name,mime_type,size_bytes,uploaded_by,created_at,updated_at) VALUES (9008,'fx/20260214.png','fx_20260214.png','image/png',12345,1003,NOW(),NOW());
