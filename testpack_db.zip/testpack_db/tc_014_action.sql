-- TC-014 action
INSERT INTO product_lots (product_id,lot_no,expiry_date,status,created_at,updated_at) VALUES (401,'LOT-A-001','2027-12-31','active',NOW(),NOW());
