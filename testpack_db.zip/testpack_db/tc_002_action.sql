-- TC-002 action
UPDATE outbound_orders SET status='shipped', shipped_at=NOW(), updated_at=NOW() WHERE id=22001;
INSERT INTO stock_transactions (client_id,product_id,lot_id,warehouse_id,location_id,txn_type,txn_date,qty_in,qty_out,ref_type,ref_id,created_by,created_at,updated_at)
VALUES (101,401,501,201,301,'outbound_ship',NOW(),0,10,'outbound_item',22101,1002,NOW(),NOW());
UPDATE stock_balances SET available_qty=available_qty-10, updated_at=NOW() WHERE id=11001;
INSERT INTO service_events (client_id,service_id,outbound_order_id,event_date,source_type,basis_applied,qty,box_count,created_at,updated_at)
VALUES (101,601,22001,NOW(),'outbound_shipped','BOX',0,2,NOW(),NOW());
