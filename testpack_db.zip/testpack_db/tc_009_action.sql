-- TC-009 action
UPDATE settlement_batches SET status='calculating', updated_at=NOW() WHERE id=24009;
INSERT INTO settlement_lines (settlement_batch_id,service_id,line_type,description,basis,qty,unit_price,currency,amount,total_amount,created_at,updated_at) VALUES (24009,601,'service','?? ??','BOX',10,1000,'KRW',10000,10000,NOW(),NOW());
UPDATE settlement_batches SET status='reviewed', krw_subtotal=10000, total_krw=10000, updated_at=NOW() WHERE id=24009;
UPDATE settlement_batches SET status='closed', closed_at=NOW(), closed_by=1003, is_provisional=0, updated_at=NOW() WHERE id=24009;
