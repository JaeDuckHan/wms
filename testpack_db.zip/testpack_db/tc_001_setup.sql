-- TC-001 setup
INSERT INTO inbound_orders (id,inbound_no,client_id,warehouse_id,inbound_date,status,created_by,created_at,updated_at)
VALUES (20001,'INB-001',101,201,'2026-02-10','arrived',1002,NOW(),NOW());
INSERT INTO inbound_items (id,inbound_order_id,product_id,lot_id,location_id,qty,created_at,updated_at)
VALUES (21001,20001,401,501,301,20,NOW(),NOW());
