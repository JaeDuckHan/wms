-- TC-003 action
UPDATE outbound_orders SET status='allocated', updated_at=NOW() WHERE id=22003;
UPDATE stock_balances SET reserved_qty=reserved_qty+5, updated_at=NOW() WHERE id=11001;
UPDATE outbound_orders SET status='shipped', shipped_at=NOW(), updated_at=NOW() WHERE id=22003;
UPDATE stock_balances SET reserved_qty=reserved_qty-5, available_qty=available_qty-5, updated_at=NOW() WHERE id=11001;
