-- TC-010 action
UPDATE invoice_sequences SET last_seq=last_seq+1, updated_at=NOW() WHERE client_id=101 AND yyyymm='202603';
INSERT INTO invoices (settlement_batch_id,client_id,invoice_no,status,issue_date,due_date,currency,total_amount,created_by,created_at,updated_at)
SELECT 24010,101,CONCAT('INV-202603-FF130-',LPAD(last_seq,3,'0')),'issued','2026-03-31','2026-04-10','KRW',10000,1003,NOW(),NOW()
FROM invoice_sequences WHERE client_id=101 AND yyyymm='202603';
UPDATE invoices SET status='sent', sent_at=NOW(), updated_at=NOW() WHERE settlement_batch_id=24010;
