-- TC-011 assert
SELECT COUNT(*)=0 AS no_null_lot_rows FROM inbound_items WHERE inbound_order_id=20011 AND deleted_at IS NULL;
