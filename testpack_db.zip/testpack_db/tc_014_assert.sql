-- TC-014 assert
SELECT COUNT(*)=1 AS unique_kept FROM product_lots WHERE product_id=401 AND lot_no='LOT-A-001' AND deleted_at IS NULL;
