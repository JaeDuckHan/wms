-- TC-007 action
UPDATE return_orders SET status='disposed', updated_at=NOW() WHERE id=23007;
UPDATE return_items SET qty_disposed=2, updated_at=NOW() WHERE id=23107;
INSERT INTO stock_transactions (client_id,product_id,lot_id,warehouse_id,location_id,txn_type,txn_date,qty_in,qty_out,ref_type,ref_id,note,created_by,created_at,updated_at)
VALUES (101,401,501,201,301,'return_dispose',NOW(),0,0,'return_item',23107,'disposed',1002,NOW(),NOW());
