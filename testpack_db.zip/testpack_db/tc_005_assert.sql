-- TC-005 assert
SELECT COUNT(*)=1 AS move_txn_created FROM stock_transactions WHERE txn_type='move_location' AND from_location_id=301 AND to_location_id=302 AND deleted_at IS NULL;
SELECT COUNT(*)>=1 AS move_service_event_created FROM service_events WHERE source_type='location_move' AND basis_applied='BOX' AND deleted_at IS NULL;
