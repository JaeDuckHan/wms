-- TC-010 setup
INSERT INTO settlement_batches (id,client_id,billing_month,exchange_rate_id,status,is_provisional,created_by,created_at,updated_at) VALUES (24010,101,'2026-03',801,'closed',0,1003,NOW(),NOW());
INSERT INTO invoice_sequences (client_id,yyyymm,last_seq,created_at,updated_at) VALUES (101,'202603',0,NOW(),NOW()) ON DUPLICATE KEY UPDATE last_seq=0,updated_at=NOW();
