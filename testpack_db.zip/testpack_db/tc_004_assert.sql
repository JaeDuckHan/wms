-- TC-004 assert
SELECT status='cancelled' AS cancelled_ok FROM outbound_orders WHERE id=22004;
SELECT reserved_qty>=0 AS reserved_released FROM stock_balances WHERE id=11001;
