-- TC-006 assert
SELECT status='restocked' AS restocked_ok FROM return_orders WHERE id=23006;
SELECT COUNT(*)=1 AS restock_txn_created FROM stock_transactions WHERE txn_type='return_restock' AND ref_id=23106 AND deleted_at IS NULL;
