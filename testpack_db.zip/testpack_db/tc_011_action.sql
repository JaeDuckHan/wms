-- TC-011 action
INSERT INTO inbound_items (id,inbound_order_id,product_id,lot_id,location_id,qty,created_at,updated_at) VALUES (21011,20011,401,NULL,301,5,NOW(),NOW());
