-- TC-003 setup
INSERT INTO outbound_orders (id,outbound_no,client_id,warehouse_id,order_date,status,created_by,created_at,updated_at) VALUES (22003,'OUT-003',101,201,'2026-02-12','confirmed',1002,NOW(),NOW());
INSERT INTO outbound_items (id,outbound_order_id,product_id,lot_id,location_id,qty,box_type,box_count,created_at,updated_at) VALUES (22103,22003,401,501,301,5,'PACK_BOX_AA',1,NOW(),NOW());
