-- TC-007 setup
INSERT INTO return_orders (id,return_no,client_id,warehouse_id,return_date,status,reason,created_by,created_at,updated_at) VALUES (23007,'RET-007',101,201,'2026-02-13','inspected','??',1002,NOW(),NOW());
INSERT INTO return_items (id,return_order_id,product_id,lot_id,location_id,qty_received,created_at,updated_at) VALUES (23107,23007,401,501,301,2,NOW(),NOW());
