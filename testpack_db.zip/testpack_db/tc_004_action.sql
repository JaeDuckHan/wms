-- TC-004 action
UPDATE outbound_orders SET status='cancelled', updated_at=NOW() WHERE id=22004;
UPDATE stock_balances SET reserved_qty=GREATEST(reserved_qty-3,0), updated_at=NOW() WHERE id=11001;
