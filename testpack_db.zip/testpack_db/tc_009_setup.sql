-- TC-009 setup
INSERT INTO settlement_batches (id,client_id,billing_month,exchange_rate_id,status,is_provisional,created_by,created_at,updated_at) VALUES (24009,101,'2026-02',801,'open',1,1003,NOW(),NOW());
