-- TC-003 assert
SELECT status='shipped' AS shipped_ok FROM outbound_orders WHERE id=22003;
SELECT reserved_qty>=0 AS reserved_non_negative FROM stock_balances WHERE id=11001;
