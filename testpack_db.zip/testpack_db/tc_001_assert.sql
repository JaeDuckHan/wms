-- TC-001 assert
SELECT status='received' AS inbound_received FROM inbound_orders WHERE id=20001;
SELECT COUNT(*)=1 AS inbound_txn_created FROM stock_transactions WHERE txn_type='inbound_receive' AND ref_id=21001 AND deleted_at IS NULL;
SELECT available_qty>=120 AS qty_increased FROM stock_balances WHERE id=11001;
