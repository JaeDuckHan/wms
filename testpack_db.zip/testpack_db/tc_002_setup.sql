-- TC-002 setup
INSERT INTO outbound_orders (id,outbound_no,client_id,warehouse_id,order_date,status,created_by,created_at,updated_at)
VALUES (22001,'OUT-001',101,201,'2026-02-11','packed',1002,NOW(),NOW());
INSERT INTO outbound_items (id,outbound_order_id,product_id,lot_id,location_id,qty,box_type,box_count,created_at,updated_at)
VALUES (22101,22001,401,501,301,10,'PACK_BOX_AA',2,NOW(),NOW());
