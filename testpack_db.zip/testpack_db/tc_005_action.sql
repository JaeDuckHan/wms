-- TC-005 action
INSERT INTO stock_transactions (client_id,product_id,lot_id,warehouse_id,from_location_id,to_location_id,txn_type,txn_date,qty_in,qty_out,ref_type,ref_id,created_by,created_at,updated_at)
VALUES (101,401,501,201,301,302,'move_location',NOW(),0,0,'location_move',50001,1002,NOW(),NOW());
INSERT INTO service_events (client_id,service_id,event_date,source_type,basis_applied,qty,box_count,stock_transaction_id,created_at,updated_at)
VALUES (101,602,NOW(),'location_move','BOX',0,1,LAST_INSERT_ID(),NOW(),NOW());
