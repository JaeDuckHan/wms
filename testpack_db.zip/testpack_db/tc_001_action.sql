-- TC-001 action
UPDATE inbound_orders SET status='received', received_at=NOW(), updated_at=NOW() WHERE id=20001;
INSERT INTO stock_transactions (client_id,product_id,lot_id,warehouse_id,location_id,txn_type,txn_date,qty_in,qty_out,ref_type,ref_id,created_by,created_at,updated_at)
VALUES (101,401,501,201,301,'inbound_receive',NOW(),20,0,'inbound_item',21001,1002,NOW(),NOW());
UPDATE stock_balances SET available_qty=available_qty+20, updated_at=NOW() WHERE id=11001;
