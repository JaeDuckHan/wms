-- TC-002 assert
SELECT status='shipped' AS shipped_ok FROM outbound_orders WHERE id=22001;
SELECT COUNT(*)=1 AS ship_txn_created FROM stock_transactions WHERE txn_type='outbound_ship' AND ref_id=22101 AND deleted_at IS NULL;
SELECT COUNT(*)=1 AS box_event_created FROM service_events WHERE outbound_order_id=22001 AND source_type='outbound_shipped' AND basis_applied='BOX' AND deleted_at IS NULL;
