-- TC-009 assert
SELECT status='closed' AS closed_ok FROM settlement_batches WHERE id=24009;
SELECT COUNT(*)>=1 AS lines_created FROM settlement_lines WHERE settlement_batch_id=24009 AND deleted_at IS NULL;
