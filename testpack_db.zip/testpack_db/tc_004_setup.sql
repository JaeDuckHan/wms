-- TC-004 setup
INSERT INTO outbound_orders (id,outbound_no,client_id,warehouse_id,order_date,status,created_by,created_at,updated_at) VALUES (22004,'OUT-004',101,201,'2026-02-12','allocated',1002,NOW(),NOW());
UPDATE stock_balances SET reserved_qty=reserved_qty+3, updated_at=NOW() WHERE id=11001;
