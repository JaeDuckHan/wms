-- TC-008 assert
SELECT status='active' AS fx_active FROM exchange_rates WHERE id=8008;
SELECT COUNT(*)>=1 AS has_attachment FROM exchange_rate_attachments WHERE exchange_rate_id=8008 AND deleted_at IS NULL;
