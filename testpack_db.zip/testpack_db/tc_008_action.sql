-- TC-008 action
INSERT INTO exchange_rate_attachments (exchange_rate_id,file_id,note,created_at,updated_at) VALUES (8008,9008,'fx evidence',NOW(),NOW());
UPDATE exchange_rates SET status='active', activated_by=1003, activated_at=NOW(), updated_at=NOW() WHERE id=8008;
