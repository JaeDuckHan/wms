-- TC-011 setup
INSERT INTO inbound_orders (id,inbound_no,client_id,warehouse_id,inbound_date,status,created_by,created_at,updated_at) VALUES (20011,'INB-011',101,201,'2026-02-11','arrived',1002,NOW(),NOW());
