-- TC-010 assert
SELECT invoice_no REGEXP '^INV-202603-FF130-[0-9]{3}$' AS invoice_no_ok, status='sent' AS sent_ok FROM invoices WHERE settlement_batch_id=24010 AND deleted_at IS NULL;
