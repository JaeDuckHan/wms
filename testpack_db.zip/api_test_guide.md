# API Auto Test Guide (Postman)

## ??
- Collection: `tests/postman/3pl_v1_collection.json`
- REST Client: `tests/rest-client/3pl_v1.http`

## ????
- `baseUrl`
- `token_admin`
- `token_manager`
- `token_warehouse`
- `token_viewer_c1`
- `token_viewer_c2`

## ?? TC
- TC-013, TC-017, TC-018, TC-019, TC-020

## ?? ??
1. TC-013 -> TC-017 -> TC-018 -> TC-019 ??? ??
2. TC-020? ?? ???? ??

## TC-020 ?? ?? ??
1. Postman?? `TC-020A`, `TC-020B`? ?? ? ??? ?? ?? ??? Send
2. ?? ????? Newman 2? ????? ??? ??

```powershell
Start-Process newman -ArgumentList "run tests/postman/3pl_v1_collection.json --folder "TC-020 Concurrent Invoice Issue" --env-var baseUrl=$env:BASE_URL --env-var token_manager=$env:TOKEN_MANAGER"
Start-Process newman -ArgumentList "run tests/postman/3pl_v1_collection.json --folder "TC-020 Concurrent Invoice Issue" --env-var baseUrl=$env:BASE_URL --env-var token_manager=$env:TOKEN_MANAGER"
```

3. ?? ??: ?? client/month?? `INV-...-001`, `INV-...-002` ?? ??(?? ??)

## ??? ??
- `docs/testpack_v1.md`? zip? ????? ???? ??
```powershell
Compress-Archive -Path "sql/testpack_db/*","tests/postman/*","tests/rest-client/*","docs/testpack_db.md","docs/api_test_guide.md","docs/testpack_v1.md" -DestinationPath "testpack.zip" -Force
```