# 3PL WMS & Settlement v1 Test Pack

## Common Assumptions
- qty uses integer only
- lot is mandatory
- stock deduction happens only at shipped
- return uses separate return slip
- settlement closed means locked (reopen required)
- client_viewer can only access own client_id rows
- soft delete is enabled (deleted_at), default query must filter deleted_at IS NULL

## Execution Guide
1. Recommended order: TC-001 to TC-010, then TC-011 to TC-020
2. Independent run: setup -> action -> assert per TC
3. Sequential run: TC-001~TC-010 can be chained for end-to-end flow
4. Transaction rule: START TRANSACTION before setup, ROLLBACK after assert
5. Exception: TC-020 concurrency case needs COMMIT, then cleanup

## TC-001 Inbound Confirm
- Objective: Verify inbound_receive stock transaction and balance increase.
- Precondition: run common seed and this TC setup SQL.
- Steps: execute tc_xxx_setup.sql -> tc_xxx_action.sql -> tc_xxx_assert.sql.
- Expected: assertions return true/1 and state follows the scenario rule.
- Files: `sql/testpack/tc_001_setup.sql`, `sql/testpack/tc_001_action.sql`, `sql/testpack/tc_001_assert.sql`

## TC-002 Outbound Deduct at Shipped
- Objective: Verify no stock change at packed, and deduction + BOX service event at shipped.
- Precondition: run common seed and this TC setup SQL.
- Steps: execute tc_xxx_setup.sql -> tc_xxx_action.sql -> tc_xxx_assert.sql.
- Expected: assertions return true/1 and state follows the scenario rule.
- Files: `sql/testpack/tc_002_setup.sql`, `sql/testpack/tc_002_action.sql`, `sql/testpack/tc_002_assert.sql`

## TC-003 Reserved Qty Flow
- Objective: Verify reserved_qty up on allocated and down on shipped.
- Precondition: run common seed and this TC setup SQL.
- Steps: execute tc_xxx_setup.sql -> tc_xxx_action.sql -> tc_xxx_assert.sql.
- Expected: assertions return true/1 and state follows the scenario rule.
- Files: `sql/testpack/tc_003_setup.sql`, `sql/testpack/tc_003_action.sql`, `sql/testpack/tc_003_assert.sql`

## TC-004 Cancel Before Ship
- Objective: Verify reserved release on cancellation before shipping.
- Precondition: run common seed and this TC setup SQL.
- Steps: execute tc_xxx_setup.sql -> tc_xxx_action.sql -> tc_xxx_assert.sql.
- Expected: assertions return true/1 and state follows the scenario rule.
- Files: `sql/testpack/tc_004_setup.sql`, `sql/testpack/tc_004_action.sql`, `sql/testpack/tc_004_assert.sql`

## TC-005 Move Location
- Objective: Verify move_location transaction and optional BOX billing event.
- Precondition: run common seed and this TC setup SQL.
- Steps: execute tc_xxx_setup.sql -> tc_xxx_action.sql -> tc_xxx_assert.sql.
- Expected: assertions return true/1 and state follows the scenario rule.
- Files: `sql/testpack/tc_005_setup.sql`, `sql/testpack/tc_005_action.sql`, `sql/testpack/tc_005_assert.sql`

## TC-006 Return Restock
- Objective: Verify return_restock transaction and stock increase.
- Precondition: run common seed and this TC setup SQL.
- Steps: execute tc_xxx_setup.sql -> tc_xxx_action.sql -> tc_xxx_assert.sql.
- Expected: assertions return true/1 and state follows the scenario rule.
- Files: `sql/testpack/tc_006_setup.sql`, `sql/testpack/tc_006_action.sql`, `sql/testpack/tc_006_assert.sql`

## TC-007 Return Dispose
- Objective: Verify return_dispose transaction with no stock increase.
- Precondition: run common seed and this TC setup SQL.
- Steps: execute tc_xxx_setup.sql -> tc_xxx_action.sql -> tc_xxx_assert.sql.
- Expected: assertions return true/1 and state follows the scenario rule.
- Files: `sql/testpack/tc_007_setup.sql`, `sql/testpack/tc_007_action.sql`, `sql/testpack/tc_007_assert.sql`

## TC-008 FX Draft->Active
- Objective: Verify FX activate requires at least one attachment.
- Precondition: run common seed and this TC setup SQL.
- Steps: execute tc_xxx_setup.sql -> tc_xxx_action.sql -> tc_xxx_assert.sql.
- Expected: assertions return true/1 and state follows the scenario rule.
- Files: `sql/testpack/tc_008_setup.sql`, `sql/testpack/tc_008_action.sql`, `sql/testpack/tc_008_assert.sql`

## TC-009 Settlement Close
- Objective: Verify settlement calculate/review/close and line generation.
- Precondition: run common seed and this TC setup SQL.
- Steps: execute tc_xxx_setup.sql -> tc_xxx_action.sql -> tc_xxx_assert.sql.
- Expected: assertions return true/1 and state follows the scenario rule.
- Files: `sql/testpack/tc_009_setup.sql`, `sql/testpack/tc_009_action.sql`, `sql/testpack/tc_009_assert.sql`

## TC-010 Invoice Issue/Send
- Objective: Verify invoice number format and sent status.
- Precondition: run common seed and this TC setup SQL.
- Steps: execute tc_xxx_setup.sql -> tc_xxx_action.sql -> tc_xxx_assert.sql.
- Expected: assertions return true/1 and state follows the scenario rule.
- Files: `sql/testpack/tc_010_setup.sql`, `sql/testpack/tc_010_action.sql`, `sql/testpack/tc_010_assert.sql`

## TC-011 Inbound Lot Missing
- Objective: Verify lot mandatory rule for inbound items.
- Precondition: run common seed and this TC setup SQL.
- Steps: execute tc_xxx_setup.sql -> tc_xxx_action.sql -> tc_xxx_assert.sql.
- Expected: assertions return true/1 and state follows the scenario rule.
- Files: `sql/testpack/tc_011_setup.sql`, `sql/testpack/tc_011_action.sql`, `sql/testpack/tc_011_assert.sql`

## TC-012 Outbound Insufficient Stock
- Objective: Verify shipping blocked when stock is insufficient.
- Precondition: run common seed and this TC setup SQL.
- Steps: execute tc_xxx_setup.sql -> tc_xxx_action.sql -> tc_xxx_assert.sql.
- Expected: assertions return true/1 and state follows the scenario rule.
- Files: `sql/testpack/tc_012_setup.sql`, `sql/testpack/tc_012_action.sql`, `sql/testpack/tc_012_assert.sql`

## TC-013 Cancel After Shipped
- Objective: Verify cancellation blocked after shipped.
- Precondition: run common seed and this TC setup SQL.
- Steps: execute tc_xxx_setup.sql -> tc_xxx_action.sql -> tc_xxx_assert.sql.
- Expected: assertions return true/1 and state follows the scenario rule.
- Files: `sql/testpack/tc_013_setup.sql`, `sql/testpack/tc_013_action.sql`, `sql/testpack/tc_013_assert.sql`

## TC-014 Duplicate Lot
- Objective: Verify unique(product_id, lot_no).
- Precondition: run common seed and this TC setup SQL.
- Steps: execute tc_xxx_setup.sql -> tc_xxx_action.sql -> tc_xxx_assert.sql.
- Expected: assertions return true/1 and state follows the scenario rule.
- Files: `sql/testpack/tc_014_setup.sql`, `sql/testpack/tc_014_action.sql`, `sql/testpack/tc_014_assert.sql`

## TC-015 Move Same Location
- Objective: Verify move blocked when from_location == to_location.
- Precondition: run common seed and this TC setup SQL.
- Steps: execute tc_xxx_setup.sql -> tc_xxx_action.sql -> tc_xxx_assert.sql.
- Expected: assertions return true/1 and state follows the scenario rule.
- Files: `sql/testpack/tc_015_setup.sql`, `sql/testpack/tc_015_action.sql`, `sql/testpack/tc_015_assert.sql`

## TC-016 Dispose Without Reason
- Objective: Verify dispose requires reason.
- Precondition: run common seed and this TC setup SQL.
- Steps: execute tc_xxx_setup.sql -> tc_xxx_action.sql -> tc_xxx_assert.sql.
- Expected: assertions return true/1 and state follows the scenario rule.
- Files: `sql/testpack/tc_016_setup.sql`, `sql/testpack/tc_016_action.sql`, `sql/testpack/tc_016_assert.sql`

## TC-017 Edit Closed Settlement
- Objective: Verify closed settlement cannot be modified.
- Precondition: run common seed and this TC setup SQL.
- Steps: execute tc_xxx_setup.sql -> tc_xxx_action.sql -> tc_xxx_assert.sql.
- Expected: assertions return true/1 and state follows the scenario rule.
- Files: `sql/testpack/tc_017_setup.sql`, `sql/testpack/tc_017_action.sql`, `sql/testpack/tc_017_assert.sql`

## TC-018 Reopen Role/Reason Invalid
- Objective: Verify reopen requires manager+ and valid reason.
- Precondition: run common seed and this TC setup SQL.
- Steps: execute tc_xxx_setup.sql -> tc_xxx_action.sql -> tc_xxx_assert.sql.
- Expected: assertions return true/1 and state follows the scenario rule.
- Files: `sql/testpack/tc_018_setup.sql`, `sql/testpack/tc_018_action.sql`, `sql/testpack/tc_018_assert.sql`

## TC-019 Portal Cross-client Access
- Objective: Verify portal row-level restriction by token.client_id.
- Precondition: run common seed and this TC setup SQL.
- Steps: execute tc_xxx_setup.sql -> tc_xxx_action.sql -> tc_xxx_assert.sql.
- Expected: assertions return true/1 and state follows the scenario rule.
- Files: `sql/testpack/tc_019_setup.sql`, `sql/testpack/tc_019_action.sql`, `sql/testpack/tc_019_assert.sql`

## TC-020 Concurrent Invoice Issue
- Objective: Verify invoice sequence concurrency safety (001/002).
- Precondition: run common seed and this TC setup SQL.
- Steps: execute tc_xxx_setup.sql -> tc_xxx_action.sql -> tc_xxx_assert.sql.
- Expected: assertions return true/1 and state follows the scenario rule.
- Files: `sql/testpack/tc_020_setup.sql`, `sql/testpack/tc_020_action.sql`, `sql/testpack/tc_020_assert.sql`
